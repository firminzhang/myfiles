import gradio as gr
import os
import requests
import json
import random
import pdfplumber
from cnocr import CnOcr
import magic

url = "http://3.8.48.225:3001/api/v1/chat/completions"
# 对jpg图片的数据处理应用
key1 = "fastgpt-8MvotuErVlVzH0XAllU4LoXahL7fqRqXizQZZDlJ84v01KoiL6ADMPunezVt"
# 对pdf文件的数据处理应用
key2 = "fastgpt-8cdslqDjiXjOEZrU9Xv9JqmlL0KVIRC5fkqeWvsWa8TKd3AANbc9nrpw9bZG"
random_uid = str(random.randint(0, 999999)).zfill(6)


# 向fastgpt发送post请求
def re_input(key, chatId, variables, query):
    headers = {
        "Authorization": f"Bearer {key}",
        "Content-Type": "application/json"
    }
    payload = {
        "chatId": chatId,
        "stream": False,
        "detail": False,
        "variables": variables,
        "messages": [
            {
                "content": query,
                "role": "user"
            }
        ]
    }
    response = requests.post(url, headers=headers, data=json.dumps(payload))
    if response.ok:
        json_data = response.json()
        output = json_data["choices"][0]["message"]["content"]
    else:
        # 如果有错误，打印错误详情
        output = "Error occurred:\n" + str(response.status_code) + "\n" + response.text
    return output


# gradio对多输入的处理
def handle_chat(var1, var2, var3, var4, chat_input, history, file_input):
    file_path = file_input.name
    mime = magic.Magic(mime=True)
    file_type = mime.from_file(file_path)
    variables = {
        "description": var1,
        "label1": var2,
        "label2": var3,
        "label3": var4,
    }
    if chat_input == '':
        file_format, all_context, context = file_pro(file_input)
        chat_input = context
        random_uid1 = str(random.randint(0, 999999)).zfill(6)
    else:
        random_uid1 = random_uid
    if 'image' in file_type:
        chat_output = re_input(key1, random_uid1, variables, chat_input)
    if 'pdf' in file_type:
        chat_output = re_input(key2, random_uid1, variables, chat_input)
    # 用户的输入作为一条消息
    user_msg = [chat_input, None]
    # Bot的响应作为一条消息
    bot_response = [None, chat_output]
    # 如果历史为空，则开始一个新列表，否则追加到现有列表
    if not history:
        history = [user_msg, bot_response]
    else:
        history.append(user_msg)
        history.append(bot_response)

    return "", history


def file_response(file_input):
    return file_input


# 对输入文件分类处理
def file_pro(file_input):
    if file_input is not None:
        file_path = file_input.name
        mime = magic.Magic(mime=True)
        file_type = mime.from_file(file_path)
        if 'image' in file_type:
            ocr = CnOcr()  # 所有参数都使用默认值
            out = ocr.ocr(file_input)
            context = ""
            for line in out:
                context = context + line['text'] + '\n'
            return "jpg", [context], context
        elif 'pdf' in file_type:
            context = []
            with pdfplumber.open(file_input) as pdf:
                for page in pdf.pages:
                    context.append(page.extract_text())
            return "pdf", context, context[0][:512]


# 选择下载文件时，对文件中的文本的批量处理
def download_file(var1, var2, var3, var4, file_input, chat_output):
    download_file_path = str(file_input.name) + ".txt"
    file_format, all_context, context = file_pro(file_input)
    if file_format == 'jpg':
        with open(download_file_path, 'a', encoding='utf-8') as file:
            if var2 or var3 or var4:
                result = chat_output[-1][1].split('***数据处理样例***')
                qa = result[-1].strip()
                label = result[0].split("***数据标注结果***")[-1].strip()
                file.write(qa + '\n')
                file.write(label + '\n\n')
            else:
                qa = chat_output[-1][1].split('***数据处理样例***')[-1].strip()
                file.write(qa + '\n\n')
    elif file_format == 'pdf':
        variables = {
            "description": var1,
            "label1": var2,
            "label2": var3,
            "label3": var4,
        }
        for text in all_context:
            random_uid2 = str(random.randint(0, 999999)).zfill(6)
            for i in range(5):
                chat_output = re_input(key2, random_uid2, variables, text)
                with open(download_file_path, 'a', encoding='utf-8') as file:
                    if var2 or var3 or var4:
                        result = chat_output.split('***数据处理样例***')
                        qa = result[-1].strip()
                        label = result[0].split("***数据标注结果***")[-1].strip()
                        file.write(qa + '\n')
                        file.write(label + '\n\n')
                    else:
                        qa = chat_output[-1][1].split('***数据生成样例***')[-1].strip()
                        file.write(qa + '\n\n')

    if os.path.exists(download_file_path):
        return download_file_path
    else:
        # 如果文件不存在，返回 None 或者可以返回错误信息
        return None


# gradio演示
with gr.Blocks() as demo:
    # 文字 Logo
    gr.Markdown(
        """
        # BBT的数据处理AI
        欢迎使用BBT开发的数据处理AI，输入信息或上传文件。
        """
    )
    with gr.Row():
        chat_output = gr.Chatbot()
    # 数据样例变量
    with gr.Row():
        var1 = gr.Textbox(label="数据处理需求描述")
        var2 = gr.Textbox(label="标注标签1")
        var3 = gr.Textbox(label="标注标签2")
        var4 = gr.Textbox(label="标注标签3")

    with gr.Row():
        # 创建文本输入框以输入聊天信息
        chat_input = gr.Textbox(placeholder="在此输入您的消息...")
        file_input = gr.File(label="上传文件")

    # 当文件上传时，触发file_response函数
    file_input.change(
        file_response,
        inputs=file_input,
        outputs=file_input
    )
    chat_input.submit(
        handle_chat,
        inputs=[var1, var2, var3, var4, chat_input, chat_output, file_input],
        outputs=[chat_input, chat_output]
    )

    # 文件下载输出组件
    file_download = gr.File(label="Download File")
    download_btn = gr.Button("Download")

    with gr.Row():
        download_btn.click(download_file, [var1, var2, var3, var4, file_input, chat_output], file_download)

demo.launch()
